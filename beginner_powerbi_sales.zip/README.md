
# Beginner Power BI – Sales Analytics Project

This beginner-friendly starter pack helps learners practice Power BI using simple sales data.

## Included Datasets:
- Customers.csv
- Products.csv
- Sales.csv

## Steps:
1. Load all CSV files into Power BI.
2. Create relationships:
   - Customers.customer_id → Sales.customer_id
   - Products.product_id → Sales.product_id
3. Create visuals:
   - Total Sales (card)
   - Sales by Region (bar chart)
   - Top Products (table)

## Notes:
Datasets are small and easy for beginners to understand.
