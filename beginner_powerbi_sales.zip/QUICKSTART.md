
# QUICKSTART GUIDE

1. Open Power BI Desktop.
2. Load Customers.csv, Products.csv, Sales.csv.
3. Build relationships using customer_id and product_id.
4. Create visuals:
   - Card: Total Sales = SUM(Products[price])
   - Bar Chart: Sales by Region
   - Table: Customer, Product, Quantity

You now have a basic Sales Dashboard!
