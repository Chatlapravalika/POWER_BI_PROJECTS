
Call Center Performance Dashboard - Power BI Project

Files:
- Call_Center_Data.csv -> Main dataset

Columns:
- Date
- Agent
- Call_Type
- Call_Status (Answered / Missed)
- Call_Duration_Seconds
- Customer_Satisfaction (1 to 5, only for answered calls)

Suggested KPIs in Power BI:
- Total Calls
- Answered vs Missed Calls
- Answer Rate %
- Average Handling Time
- Agent Performance
- Customer Satisfaction Score
- Calls by Type
- Calls by Date/Month

Suggested Visuals:
- KPI Cards
- Bar Chart: Calls by Agent
- Pie/Donut: Call Status
- Line Chart: Calls by Date
- Table: Agent Performance
- Slicers: Date, Agent, Call Type

You can directly load the CSV into Power BI and start building the dashboard.
