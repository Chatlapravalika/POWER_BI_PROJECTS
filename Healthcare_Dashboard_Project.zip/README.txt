Healthcare Analytics Dashboard – Power BI Project

Files:
- Patient.xlsx
- Doctor.xlsx
- Department.xlsx

Steps to Build:
1. Open Power BI Desktop
2. Click Get Data -> Excel -> Load all three files
3. Create relationships:
   - Patient[Doctor] -> Doctor[DoctorName]
   - Patient[Department] -> Department[Department]
4. Create Measures (DAX):
   - Total Patients = COUNT(Patient[PatientID])
   - Total Revenue = SUM(Patient[TreatmentCost])
   - Avg Stay Days = AVERAGE(Patient[HospitalStayDays])
   - Avg Treatment Cost = AVERAGE(Patient[TreatmentCost])

5. Create Pages:
   Page 1: Hospital Overview
   - Cards: Total Patients, Total Revenue, Avg Stay Days
   - Line: Patients by AdmitDate (Month)
   - Bar: Patients by Department
   - Pie: Gender Distribution

   Page 2: Doctor Performance
   - Bar: Patients by Doctor
   - Bar: Revenue by Doctor
   - Table: Doctor, Patients, Revenue

   Page 3: Disease Analysis
   - Bar: Patients by Disease
   - Line: Trend by Month

6. Add Slicers:
   - Department, Doctor, City, Gender, Date

Resume Description:
Built an interactive Healthcare Analytics Dashboard in Power BI to analyze patient flow, hospital performance, doctor efficiency, and disease trends using DAX and Power Query.