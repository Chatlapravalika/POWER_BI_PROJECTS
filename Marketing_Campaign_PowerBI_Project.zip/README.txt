
Marketing Campaign Performance Dashboard - Power BI Project

Files:
- Marketing_Campaign_Data.csv -> Main dataset

Columns:
- Date
- Campaign
- Region
- Channel
- Impressions
- Clicks
- Leads
- Conversions
- Cost
- Revenue

Suggested KPIs:
- Total Cost
- Total Revenue
- ROI
- CTR (Click Through Rate)
- Conversion Rate
- Cost per Lead
- Cost per Conversion

Suggested Visuals:
- KPI Cards
- Bar Chart: Revenue by Campaign
- Bar Chart: Cost by Channel
- Line Chart: Revenue Trend by Date
- Table: Campaign Performance
- Donut Chart: Channel Split
- Slicers: Date, Campaign, Region, Channel
