
Retail Store Dashboard - Power BI Project

This project analyzes retail sales data using Power BI.

Files Included:
1. Retail_Sales_Data.csv – Dataset
2. README.txt – Project description

Dashboard Features:
- Total Sales & Profit
- Category-wise analysis
- Region-wise performance
- KPI cards
- Interactive filters

Tools Used:
- Power BI
- MS Excel

Use:
1. Open Power BI
2. Load Retail_Sales_Data.csv
3. Create visuals using charts and slicers
