
Supermarket Sales Analysis – Power BI Project

Files:
1. supermarket_sales_data.xlsx – Dataset
2. analysis_insights.txt – Analysis sheet content

How to use:
1. Open Power BI
2. Load supermarket_sales_data.xlsx
3. Create visuals as per analysis_insights.txt
