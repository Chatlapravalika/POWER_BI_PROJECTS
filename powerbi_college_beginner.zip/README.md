# Power BI - College Analytics (Beginner Starter Pack)

This beginner-friendly ZIP provides tiny sample CSV datasets and a simple step-by-step guide to build your first Power BI report.

## What's included
- Students.csv
- Courses.csv
- Enrollments.csv
- Attendance.csv
- README.md (this file)
- QUICKSTART.md (one-page quick start guide)
- DAX_CHEATSHEET.md (very simple DAX examples)

## Quick Goals for beginners
1. Load the CSVs into Power BI.
2. Create relationships between tables (Student ID, Course ID).
3. Make 3 visuals: card (Total Students), bar chart (Students by Department), table (Enrollments with Grades).
4. Create a simple measure: Average Grade (numeric) or Count of Enrollments.
5. Save your .pbix and upload to GitHub.

## Notes
- PBIX (Power BI file) cannot be generated here; create it using Power BI Desktop.
- The datasets are intentionally tiny for easy exploration.
