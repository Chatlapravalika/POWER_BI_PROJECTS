# DAX Cheatsheet (Very Basic)

## Simple Measures
Total Students (distinct count):
```
Total Students = DISTINCTCOUNT(Students[student_id])
```

Total Enrollments (count rows):
```
Total Enrollments = COUNTROWS(Enrollments)
```

Average Marks (if numeric marks column exists):
```
Average Marks = AVERAGE(Results[marks_obtained])
```

Attendance % (simple example):
```
Present Count = CALCULATE(COUNTROWS(Attendance), Attendance[status] = "present")
Attendance % = DIVIDE([Present Count], COUNTROWS(Attendance), 0)
```

## Tips
- Start with simple measures, verify values in a table visual.
- Use a Date table for time intelligence (not included in this simple pack).
- Use Slicers to filter by Department or Year.
