# QUICKSTART: Build your first report (5–10 minutes)

1. Open Power BI Desktop.
2. Click **Get Data** -> **Text/CSV** -> select Students.csv. Click **Load**.
3. Repeat to load Courses.csv, Enrollments.csv, Attendance.csv.
4. Go to **Model** view. Create relationships:
   - Students.student_id -> Enrollments.student_id
   - Courses.course_id -> Enrollments.course_id
   - Students.student_id -> Attendance.student_id
   - Courses.course_id -> Attendance.course_id
5. Switch to **Report** view.
6. Add a **Card** visual: drag any field to show Total Students.
   - Better: create measure `Total Students = DISTINCTCOUNT(Students[student_id])`
7. Add a **Bar Chart**: Axis = Students[dept], Value = DISTINCTCOUNT(Students[student_id])
8. Add a **Table**: Columns = Students[name], Courses[course_code], Enrollments[grade]
9. Save the report (`File` -> `Save`) as `College_Beginner.pbix` (on your machine).
10. To publish/upload to GitHub: add the PBIX or the CSVs and README to a repository.

Congrats — you built your first Power BI report!
