
Call Center Performance Dashboard - Dataset

File:
- CallCenter_Data.csv

Columns:
- Call_ID
- Date
- Agent_Name
- Department
- Call_Duration (seconds)
- Wait_Time (seconds)
- Answered (Yes/No)
- Resolved (Yes/No)
- Customer_Rating (1-5)
- Call_Type

Use this file in Power BI to build:
- Agent Performance Dashboard
- Call Trends
- CSAT Analysis
- Resolution & Answer Rate KPIs
