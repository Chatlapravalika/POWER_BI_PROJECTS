# HR Analytics Dashboard (Power BI)

Beginner-friendly HR Analytics project using Power BI.

## KPIs
- Total Employees
- Attrition Count & Rate
- Average Monthly Income
- Employees by Department

## Visuals to Create
- Cards (KPIs)
- Bar chart (Department-wise employees)
- Pie chart (Attrition)
- Column chart (Job Role vs Income)
- Slicers (Department, Gender)

## Steps
1. Open Power BI Desktop
2. Load hr_data.csv
3. Create measures and visuals
4. Build interactive dashboard

## Tools
- Power BI Desktop
